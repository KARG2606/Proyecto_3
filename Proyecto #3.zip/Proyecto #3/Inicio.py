import pygame
import sys
import os
import Preguntas

# Inicializar Pygame
pygame.init()

# Definir dimensiones de la ventana
screen_info = pygame.display.Info()
width = screen_info.current_w
height = screen_info.current_h 

#Configuración inicial del volumen de la música
volum= 0.3

#Cargar y reproducir la música en bucle
pygame.mixer.music.load("superheroes-marvel.mp3")  # Cargar la música (puede ser .mp3, .ogg, etc.)
pygame.mixer.music.play(-1)  # Reproducir en bucle (-1 significa que se repetirá indefinidamente)
pygame.mixer.music.set_volume(volum)

# Crear la ventana en modo pantalla completa
screen = pygame.display.set_mode((width, height), pygame.FULLSCREEN)
pygame.display.set_caption("Triviesa")

#Obtener la ruta del archivo actual
ruta_running = os.path.dirname(os.path.abspath(__file__)) 

#Cargar y escalar la imagen de fondo a las dimenciones de la pantalla
image = pygame.image.load(ruta_running + "\\Fondo.jpeg")
image = pygame.transform.scale(image, (width, height))

# Colores
black = (0, 0, 0)
white = (255, 255, 255) 
red = (255, 0, 0)

#Cargar la fuente desde el archivo
ruta_fuente = ruta_running + "\\Press_Start_2P\\PressStart2P.ttf"
font = pygame.font.Font(ruta_fuente, 36)

#Definir las dimensiones y la posición del botón
button_rect = pygame.Rect((width // 2 - 130, height // 2 + 60), (250, 100))

#Función para dibujar el botón en la pantalla
def draw_button(screen, text):
    pygame.draw.rect(screen, black, button_rect)
    text_surf = font.render(text, True, white)
    text_rect = text_surf.get_rect(center=button_rect.center)
    screen.blit(text_surf, text_rect)

#Función para limpiar la pantalla
def clean_screen():
    screen.fill(black)
    pygame.display.flip()

#Función para pedir el nombre del usuario
def pedir_nombre(screen, font):
    nombre = ""
    ingresando_nombre = True
    while ingresando_nombre:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if len(nombre) > 2:  # Verificar si la longitud del nombre es mayor que 2
                        ingresando_nombre = False
                elif event.key == pygame.K_BACKSPACE:
                    if len(nombre) > 0:  # Verificar si hay algo que borrar
                        nombre = nombre[:-1]
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                else:
                    if len(nombre)>=0 and len(nombre)<= 12:
                            nombre += event.unicode
        
        # Limpiar pantalla
        screen.fill(black)
        
        # Mostrar el texto ingresado
        nombre_surf = font.render(f"Nombre: {nombre}", True, white)
        screen.blit(nombre_surf, (width // 2 - nombre_surf.get_width() // 2, height // 2))

        pygame.display.flip()
    
    return nombre

# Solicitar nombre antes del bucle principal
nombre = pedir_nombre(screen, font)
with open("Registro.txt", 'a+') as registro:
    registro.write(f'Jugador: {nombre}, ')
        
# Bucle principal
running = True
clean_screen_flag = False

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            if event.key == pygame.K_BACKSPACE:
                clean_screen_flag = False 
            if event.key == pygame.K_p:  # Aumentar volumen
                volum += 0.05
                pygame.mixer.music.set_volume(volum)
            if event.key == pygame.K_o:  # Disminuir volumen
                volum -= 0.05
                pygame.mixer.music.set_volume(volum)
        if event.type == pygame.MOUSEBUTTONDOWN:
            if button_rect.collidepoint(event.pos):
                clean_screen_flag = True

    # Si la bandera está activa, limpiar pantalla
    if clean_screen_flag:
        clean_screen()
        Preguntas.iniciar(screen)
        clean_screen_flag = False
    else:
        # Dibujar la imagen
        screen.blit(image, (0, 0))

        # Dibujar el botón
        draw_button(screen, "Iniciar")
        # Actualizar la pantalla
        pygame.display.flip()

# Salir de Pygame
pygame.quit()
sys.exit()
