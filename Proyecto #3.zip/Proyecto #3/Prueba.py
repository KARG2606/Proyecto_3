import pygame
import sys

# Inicializar pygame
pygame.init()

# Configuración de la pantalla completa
screen_width = pygame.display.Info().current_w  # Ancho de la pantalla completa
screen_height = pygame.display.Info().current_h  # Alto de la pantalla completa
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)
pygame.display.set_caption('Pantallas de Muerte y Victoria')

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Cargar las imágenes de fondo
fondo_muerte = pygame.image.load("muerte.jpg")  # Asegúrate de tener la imagen de fondo de muerte
fondo_victoria = pygame.image.load("victoria.jpg")  # Asegúrate de tener la imagen de fondo de victoria

# Redimensionar las imágenes para ajustarlas a la pantalla completa
fondo_muerte = pygame.transform.scale(fondo_muerte, (screen_width, screen_height))
fondo_victoria = pygame.transform.scale(fondo_victoria, (screen_width, screen_height))

# Cargar fuente Arcade
arcade_font = pygame.font.SysFont("Arial", 48)  # Cambiar esto si tienes una fuente personalizada

# Variables de estadísticas
correctas = 10
incorrectas = 5
puntos = 100

# Función para mostrar estadísticas en pantalla (con separación adecuada de renglones)
def mostrar_estadisticas():
    # Establecer el texto de las estadísticas
    correctas_text = f"correctas = {correctas}"
    incorrectas_text = f"incorrectas = {incorrectas}"
    puntos_text = f"puntos = {puntos}"

    # Crear superficies de texto para cada estadística
    correctas_surface = arcade_font.render(correctas_text, True, WHITE)
    incorrectas_surface = arcade_font.render(incorrectas_text, True, WHITE)
    puntos_surface = arcade_font.render(puntos_text, True, WHITE)

    # Espacio adicional antes de las estadísticas
    y_offset = 30  # Ajuste para el espacio inicial adicional (antes de la primera estadística)

    # Posicionar el texto de las estadísticas con espacio entre ellas
    screen.blit(correctas_surface, (10, y_offset))  # "correctas" en la parte superior
    screen.blit(incorrectas_surface, (10, y_offset + correctas_surface.get_height() + 10))  # "incorrectas" debajo de "correctas"
    screen.blit(puntos_surface, (10, y_offset + correctas_surface.get_height() + incorrectas_surface.get_height() + 20))  # "puntos" debajo de "incorrectas"

# Función para la pantalla de muerte
def pantalla_muerte():
    screen.fill(BLACK)  # Rellenar la pantalla de negro
    screen.blit(fondo_muerte, (0, 0))  # Fondo de muerte
    mostrar_estadisticas()  # Muestra estadísticas en la esquina superior izquierda
    pygame.display.flip()

# Función para la pantalla de victoria
def pantalla_victoria():
    screen.fill(BLACK)  # Rellenar la pantalla de negro
    screen.blit(fondo_victoria, (0, 0))  # Fondo de victoria
    mostrar_estadisticas()  # Muestra estadísticas en la esquina superior izquierda
    pygame.display.flip()

# Función para reiniciar el juego (solo reinicia las estadísticas)
def reiniciar_juego():
    global correctas, incorrectas, puntos
    correctas = 10
    incorrectas = 5
    puntos = 100
    pantalla_muerte()  # Mostrar la pantalla de muerte al reiniciar el juego

# Función principal para manejar la lógica del juego
def main():
    global correctas, incorrectas, puntos
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                # Si el jugador presiona Enter en la pantalla de victoria
                if event.key == pygame.K_RETURN:  # Simular victoria con Enter
                    pantalla_victoria()

                # Lógica para reiniciar el juego desde la pantalla de muerte
                if event.key == pygame.K_SPACE:  # Reiniciar el juego con espacio
                    reiniciar_juego()

                # Volver al menú principal desde la pantalla de victoria o muerte
                if event.key == pygame.K_RETURN:  # Volver al menú principal con Enter
                    running = False  # Cerrar o reiniciar el juego

        pygame.display.update()

# Llamar a la función principal
main()

# Finalizar Pygame
pygame.quit()
sys.exit()
