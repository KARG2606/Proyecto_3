import pygame
import sys
import os
import scapeTheQuestBiomas as game
import time

pygame.init()
# Definir dimensiones de la ventana
screen_info = pygame.display.Info()
width = screen_info.current_w
height = screen_info.current_h 

#Obtener la ruta del directorio
ruta_running = os.path.dirname(os.path.abspath(__file__)) 

#Cargar la imagen y escalarla al tamaño de la pantalla
image = pygame.image.load(ruta_running + "\\Fondo2.jpg")
image = pygame.transform.scale(image, (width, height))

#Cargar la imagen y escalar al tamaño de la pantalla
fondo = pygame.image.load(ruta_running + "\\Trivia.jpeg")
fondo = pygame.transform.scale(fondo, (width, height))

#Definir la ruta del archivo de fuente y cargar la fuente con diferentes tamaños
ruta_fuente = ruta_running + "\\Press_Start_2P\\PressStart2P.ttf"
font = pygame.font.Font(ruta_fuente, 26)
font2 = pygame.font.Font(ruta_fuente, 12)

# Colores
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)

# Posiciones de los marcadores
marque_positions = [
    (width // 4, height // 2 - 95),
    (width // 4, height // 2 - 45),
    (width // 4, height // 2),
    (width // 4, height // 2 + 45),
    (width // 4, height // 2 + 95)
]
# Palabras para los marcadores
palabras = ["Bosque", "Espacio", "Desierto", "Océano", "Sabana"]
palabras2 = ["Bosque", "Espacio", "Desierto", "Océano", "Sabana"]

# Estados de los marcadores (False = palabra, True = "X")
marcados = [False] * 5
button_rect = pygame.Rect((width // 2 + 100, height // 2 + 100), (250, 100))
button_A = pygame.Rect((width // 2 - 125, height // 2 - 150), (250, 100)) 
button_B = pygame.Rect((width // 2 - 125, height // 2 - 30), (250, 100)) 
button_C = pygame.Rect((width // 2 - 125, height // 2 + 90), (250, 100)) 
button_exit = pygame.Rect((width // 2 - 125, height // 2 + 210), (250, 100))

correctas = 0
incorrectas = 0
puntos = 0

class ArbolBinario:
    def __init__(self, valor=None, nivel=1):
        self.valor = valor
        self.izquierdo = None
        self.derecho = None
        self.nivel = nivel

    def construir_arbol(self, lista_tuplas):
        self._construir_arbol_completo(lista_tuplas)

    def _construir_arbol_completo(self, lista_tuplas, nivel=1):
        if not lista_tuplas or nivel > 5:
            return None
        mid = len(lista_tuplas) // 2
        nodo = ArbolBinario(lista_tuplas[0], nivel)
        nodo.izquierdo = self._construir_arbol_completo(lista_tuplas[1:mid+1], nivel + 1)
        nodo.derecho = self._construir_arbol_completo(lista_tuplas[mid + 1:], nivel + 1)
        return nodo

    def recorrer_interactivamente(self,screen, bioma, volum, cant_errores, cant_correctas, point):
        """ Método para recorrer el árbol binario de manera interactiva. 
        
        Parameters: 
        screen (pygame.Surface): Superficie donde se mostrará la interacción. 
        bioma (str): Nombre del bioma actual del juego. 
        
        Este método presenta una pregunta en la pantalla y permite al usuario 
        seleccionar una respuesta. Dependiendo de la respuesta, el jugador 
        se moverá al nodo izquierdo o derecho del árbol binario. 
        Si la respuesta es correcta, se aumenta la velocidad del juego. 
        
        Si se alcanza un nodo hoja, el bucle termina. Si se cierran la ventana 
        o se presiona la tecla de escape, el juego termina. 
        
        Este método utiliza Pygame para manejar eventos y actualizar la pantalla. 
        """
        nodo = self
        Velocidad = 0
        mientras =  True
        while mientras:
            mostrar = True
            try:
                while mostrar:
                    flag= False
                    correct = False
                    respuesta= nodo.valor[2]
                    respuesta = respuesta.replace('Respuesta:', '')
                    pregunta = nodo.valor[0]
                    # Renderizar el texto con la fuente definida 
                    text_surf = font2.render(pregunta, True, white) 
                    # Obtener el rectángulo del texto para centrarlo 
                    text_rect = text_surf.get_rect(center=(width // 2, height // 4))
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                return
                            if event.key == pygame.K_p:  # Aumentar volumen
                                volum += 0.05
                                pygame.mixer.music.set_volume(volum)
                            if event.key == pygame.K_o:  # Disminuir volumen
                                volum -= 0.05
                                pygame.mixer.music.set_volume(volum)
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            if button_A.collidepoint(event.pos):
                                flag=True
                                if " "+ a ==respuesta:
                                    correct=True
                            elif button_B.collidepoint(event.pos):
                                flag=True
                                if b == respuesta:
                                    correct = True
                            elif button_C.collidepoint(event.pos):
                                flag = True
                                if c == respuesta:
                                    correct = True
                            elif button_exit.collidepoint(event.pos):
                                return

                    if flag:
                        if correct:
                            point+=1
                            cant_correctas+=1
                            nodo= nodo.izquierdo
                            if game.Juego(bioma, Velocidad,True):
                                return
                            else:
                                continue
                        else:
                            cant_errores+=1
                            errores = nodo.valor[3]
                            cambiar_errores(pregunta, errores+1, bioma)
                            nodo = nodo.derecho
                            if game.Juego(bioma, Velocidad + 1, False):
                                return
                            else:
                                point+=1.5
                                continue
                    else:
                        a,b,c = nodo.valor[1].split(',')
                        # Aquí se muestran las preguntas
                        screen.blit(fondo, (0,0))
                        screen.blit(text_surf, text_rect)
                        draw_button2(screen, f'{a}', button_A)
                        draw_button2(screen, f'{b}', button_B)
                        draw_button2(screen, f'{c}', button_C)
                        draw_button2(screen, 'Salir', button_exit)
                        pygame.display.flip()

            except AttributeError:
                return cant_errores, cant_correctas, point
        

def cambiar_errores(pregunta, cant_errores, bioma):

    """ Función para actualizar el número de errores asociados a una pregunta específica en un archivo de texto. 
    
    Parameters: 
    pregunta (str): La pregunta específica cuyo número de errores se desea actualizar. 
    cant_errores (int): El nuevo número de errores para la pregunta. 
    bioma (str): El nombre del bioma (que se usa para formar el nombre del archivo). 
    Proceso: 
    1. Crear un archivo temporal para escribir los datos actualizados. 
    2. Leer el archivo original línea por línea. 
    3. Copiar cada línea al archivo temporal. 
    4. Cuando se encuentra la pregunta específica, se leen las líneas siguientes (opciones, respuesta, errores) y se actualiza el número de errores. 
    5. Reemplazar el archivo original con el archivo temporal. 
    6. Imprimir un mensaje de confirmación al final.
    """
    archivo_temp = bioma + '_temp.txt'
    archivo_origen = bioma + '.txt'

    with open(archivo_origen, 'r', encoding='utf-8') as archivo, open(archivo_temp, 'w', encoding='utf-8') as temp:
        while True:
            linea = archivo.readline()
            if not linea:
                break

            temp.write(linea)

            if linea.strip().startswith('Pregunta:') and pregunta in linea:
                # Escribir las siguientes líneas tal cual
                opciones = archivo.readline()
                temp.write(opciones)
                respuesta = archivo.readline()
                temp.write(respuesta)

                # Modificar la línea de errores
                errores = archivo.readline()
                if errores.strip().startswith('Errores:'):
                    temp.write(f'Errores: {cant_errores}\n')
            else:
                # Continuar con la siguiente línea
                continue

    os.remove(archivo_origen)
    os.rename(archivo_temp, archivo_origen)
    print("El número de errores ha sido actualizado.")

def comienzo(eleccion):
    """ Función para inicializar y construir un árbol binario a partir de un archivo de preguntas. 
    
    Parameters: 
    eleccion (str): Nombre del bioma seleccionado, que se utilizará para construir el nombre del archivo de preguntas. 
    
    Returns: 
    arbol (ArbolBinario): Un objeto de tipo ArbolBinario que representa el árbol binario construido a partir de las preguntas. 
    """
    ruta = os.path.dirname(os.path.abspath(__file__))
    preguntas_list = []
    respuestas = []
    errores = []
    opciones = []
    preguntas_info = []
    # Especifica el nombre del archivo correcto
    bioma = f'\\{eleccion}.txt'

    with open(ruta + bioma, 'r', encoding='utf-8') as preguntas:
        for line in preguntas:
            if line.strip().startswith('Pregunta:'):
                nueva_linea = line.strip().replace('Pregunta:', '', 1).strip()
                preguntas_list.append(nueva_linea)
            elif line.strip().startswith('Respuesta:'):
                nueva_respuesta = line.strip().replace('Respuesta Correcta:', '', 1).strip()
                respuestas.append(nueva_respuesta)
            elif line.strip().startswith('Opciones:'):
                new_opcion = line.strip().replace('Opciones:', '', 1).strip()
                opciones.append(new_opcion)
            elif line.strip().startswith('Errores:'):
                new_error = line.strip().replace('Errores:', '', 1).strip()
                errores.append(int(new_error))

    # Asegurarse de que todas las listas tengan la misma longitud
    if len(preguntas_list) == len(respuestas) == len(opciones) == len(errores):
        for i in range(len(preguntas_list)):
            preguntas_info.append((preguntas_list[i], opciones[i], respuestas[i], errores[i]))
        
        # Ordenar la lista de tuplas por el cuarto elemento (errores) de menor a mayor
        preguntas_ordenadas = sorted(preguntas_info, key=lambda x: x[3])

    # Crear el árbol binario y construir el árbol completo
    arbol = ArbolBinario()
    arbol = arbol._construir_arbol_completo(preguntas_ordenadas)

    # Recorrer el árbol iterativamente
    return arbol

def clean_screen(screen):
    """ Función para limpiar la pantalla. 
    Parametros: 
    screen (pygame.Surface): Superficie donde se dibuja el contenido. 
    """
    screen.fill(black)
    pygame.display.flip()

def draw_marque(screen, pos, marcado, palabra):
    """ Función para dibujar un marcador en la pantalla. 
    Parametros: 
    screen (pygame.Surface): Superficie donde se dibuja el contenido. 
    pos (tuple): Posición (x, y) donde se dibuja el marcador. marcado 
    (bool): Estado del marcador (True para "X", False para la palabra). 
    palabra (str): Texto que se mostrará en el marcador. 
    
    Returns: 
    text_rect (pygame.Rect): Rectángulo del texto dibujado. 
    """
    if marcado:
        text = font.render(palabra, True, green)
        x_text = font.render("X", True, red)
        text_rect = text.get_rect(center=pos)
        x_rect = x_text.get_rect(midleft=(text_rect.right + 10, text_rect.centery))
        screen.blit(text, text_rect)
        screen.blit(x_text, x_rect)
    else:
        text = font.render(palabra, True, white)
    text_rect = text.get_rect(center=pos)
    screen.blit(text, text_rect)
    return text_rect

def draw_button(screen, text, button):
    """ Función para dibujar un botón en la pantalla. 
    Parametros: 
    screen (pygame.Surface): Superficie donde se dibuja el contenido. 
    text (str): Texto que se mostrará en el botón. 
    button (pygame.Rect): Rectángulo que define la posición y tamaño del botón. 
    """
    pygame.draw.rect(screen, black, button)
    text_surf = font.render(text, True, white)
    text_rect = text_surf.get_rect(center=button.center)
    screen.blit(text_surf, text_rect)

def draw_button2(screen, text, button):
    """ Función para dibujar un botón en la pantalla con una fuente más pequeña. 
    Parametros: 
    screen (pygame.Surface): Superficie donde se dibuja el contenido. 
    text (str): Texto que se mostrará en el botón. 
    button (pygame.Rect): Rectángulo que define la posición y tamaño del botón. 
    """
    pygame.draw.rect(screen, black, button)
    text_surf = font2.render(text, True, white)
    text_rect = text_surf.get_rect(center=button.center)
    screen.blit(text_surf, text_rect)

def mostrar_preguntas(screen, palabras):
    """ Función para mostrar las preguntas en la pantalla y gestionar la música de fondo. 
    Parametros: 
    screen (pygame.Surface): Superficie donde se dibuja el contenido. 
    palabras (list): Lista de biomas/palabras que se utilizarán para mostrar las preguntas. 
    """
    global correctas, incorrectas, puntos
    pygame.mixer_music.stop()
    # Musica
    volum= 0.3
    pygame.mixer.music.load("creation-marvel.mp3")  # Cargar la música 
    pygame.mixer.music.set_volume(volum)
    pygame.mixer.music.play(-1)  # Reproducir en bucle (-1 significa que se repetirá indefinidamente)
    nivel = 0
    for bioma in palabras:
        arbol = comienzo(bioma)
        cant_errores = 0
        cant_correctas = 0
        point = 0
        try:
            I, C, P= arbol.recorrer_interactivamente(screen,bioma, volum, cant_errores, cant_correctas, point)
            correctas += C
            incorrectas += I
            puntos += P
            nivel+=1
            pantalla = True
            clean_screen(screen)
            # Mostrar datos del nivel
            while pantalla:
                text1 = font.render(f"Correctas: {C}", True,black)  
                text_rect1 = text1.get_rect(center= (300,100))
                text2 = font.render(f"Incorrectas: {I}", True, black)  
                text_rect2 = text2.get_rect(center= (300,200))
                text3 = font.render(f"Puntos: {P}", True, black)  
                text_rect3 = text3.get_rect(center= (300,300))
                text4 = font.render(f"Nivel: {nivel}", True, black)  
                text_rect4 = text4.get_rect(center= (300,500))
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if button_rect.collidepoint(event.pos):
                            pantalla=False

                screen.fill(green)           
                screen.blit(text1,text_rect1)
                screen.blit(text2,text_rect2)
                screen.blit(text3,text_rect3)
                screen.blit(text4,text_rect4)
                draw_button(screen, 'Continuar', button_rect)
                pygame.display.flip()

        except TypeError:
            with open('Registro.txt', 'a', encoding='utf-8') as registro:
                registro.write(f"Incorrectas: {incorrectas}, Correctas: {correctas}, Puntos: {puntos}\n")
                return

    with open('Registro.txt', 'a', encoding='utf-8') as registro:
        registro.write(f"Incorrectas: {incorrectas}, Correctas: {correctas}, Puntos: {puntos}\n")
        return

def iniciar(screen):
    """Funcion para inicializar la pantalla y gestionar los eventos del juego.

    Parametros:
        screen (pygame.surface): Superficie donde se dibuja el contenido del juego.
    """
    running = True
    clean_screen_flag = False
    bioma = None
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for i, pos in enumerate(marque_positions):
                    text_rect = draw_marque(screen, pos, marcados[i], palabras[i])
                    if text_rect.collidepoint(event.pos):
                        # Desmarcar todos los otros marcadores
                        for j in range(len(marcados)):
                            if j != i:
                                marcados[j] = False
                        # Marcar o desmarcar el marcador actual
                        marcados[i] = not marcados[i]
                        if marcados[i]:
                            bioma = palabras[i] 
                        else:
                            bioma = None

                if button_rect.collidepoint(event.pos):
                    if bioma:
                        clean_screen_flag = True
        
        if clean_screen_flag:
            clean_screen(screen)
            if bioma != palabras[0]:
               palabras.remove(bioma)
               palabras.insert(0, bioma)

            mostrar_preguntas(screen, palabras) 
            running = False
            
        else:
            # Limpiar la pantalla
            screen.blit(image,(0,0))
            
            # Dibujar el botón
            draw_button(screen, "Seleccionar", button_rect)
            
            # Dibujar los marcadores y obtener sus rectángulos
            for i, pos in enumerate(marque_positions):
                draw_marque(screen, pos, marcados[i], palabras[i])

            # Actualizar la pantalla
            pygame.display.flip()