import pygame
import threading
import time
import os
import sys
import Preguntas
pygame.init()

# Inicializar Pygame y el módulo de sonido
pygame.init()
pygame.mixer.init()  # Inicializar el mezclador de sonidos

# Cargar y reproducir la música de fondo
pygame.mixer.music.load("superheroes-marvel.mp3")  # Cargar la música (puede ser .mp3, .ogg, etc.)
pygame.mixer.music.play(-1)  # Reproducir en bucle (-1 significa que se repetirá indefinidamente)
pygame.mixer.music.set_volume(0.4)

# Configuración de la pantalla
screen_info = pygame.display.Info()
screen_width = screen_info.current_w    #ancho de la pantalla según la resolución del monitor
screen_height = screen_info.current_h   #alto de la pantalla según la resolución del monitor

#Crear la ventana en modo pantalla completa
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)

#Establecer un fondo
fond = pygame.font.Font(None,74)
    
# Cargar la imagen del ícono
icon = pygame.image.load(f"icon_trivia.ico")

# Establecer el ícono de la ventana
pygame.display.set_icon(icon)

# Cargar la imagen del obstáculo
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Variables de movimiento
move_speed = 1
move_speed1_6 = 3.5  # Velocidad de movimiento en píxeles
move_speed2_7 = 2.5
move_speed3_8 = 5
move_speed4_9 = 3
move_speed5_10 = 5


moving_down = True  # Dirección inicial del obstáculo
estado = {"pause":False} #pone pausa al juego


Velocidad = 0
Limite_Izquierda = 0
llegada = 0


def Juego(B,N_V,R):
    """
    Función principla del juego, configura el entorno, los obstáculos y maneja el movimiento del personaje, 
    también hace verificaciones que dependerán de la verdad o falsedad de cada respuesta.

    Args:
        B (_type_): Bioma selecionado
        N_V (_type_): Nivel de velocidad incrementada
        R (_type_): Resultado de la pregunta (True para correcta, False para incorrecta)

    """
    global llegada
    global Velocidad
    global fond
    Obstaculo = ""
    #Mostrar texto dependiendo del resultado de la pregunta
    if R: 
       text = fond.render("Correcto", True,GREEN)  
       text_rect = text.get_rect(center= (300,100))
    else:
       text = fond.render("Incorrecto", True,RED)  
       text_rect = text.get_rect(center= (300,100))
    
    #incrementa la velocidad dependiendo de la respuesta
    Velocidad = Velocidad + N_V 
    #Configura la ruta de imagenes
    ruta_imagenes = os.path.dirname(os.path.abspath(__file__)) 
    if B == "Bosque":
        C = 1
        Obstaculo = "tronco.jpeg"
    elif B == "Espacio":
        C = 2
        Obstaculo = "Meteorito.jpeg"
    elif B == "Océano":
        C = 3
        Obstaculo = "Erizo.jpeg"
    elif B == "Desierto":
        Obstaculo = "Calabera.jpeg"
        C = 4
    elif B == "Sabana":
        C = 5
        Obstaculo = "Escorpion.jpeg"
        
    try: 
        #Cargar la imagen de fondo del bioma
        background_path = os.path.join(ruta_imagenes, f"{C}.jpeg") 
        background = pygame.image.load(background_path) 
    except FileNotFoundError: 
        print(f"Error: No se encontró el archivo {C}.jpeg en {ruta_imagenes}") 
        return
    ##carga imágenes del jugador
    images_der = [pygame.image.load(f"imagenes_der/Player_{i}.png") for i in range(7)]
    images_iz =[pygame.image.load(f"imagenes_iz/Player_{i}.png") for i in range(7)]
    #Carga y escala la imagen de meta
    Meta1 = pygame.image.load("Meta.jpeg")
    Meta1 = pygame.transform.scale(Meta1, (100,400))
    Posición_Meta1 = (1350,500)
    rect_meta1 = Meta1.get_rect(topleft = Posición_Meta1)
    
    
    class Jugador:
        """
        Clase que representa al jugador
        """
        def __init__(self): 
            self.images_der = images_der 
            self.images_iz = images_iz
            self.images = self.images_der
            self.image_index = 0 
            self.image = self.images_der[self.image_index] 
            self.rect = self.image.get_rect() 
            self.rect.topleft = (screen_width // 2, screen_height // 1.5) 
            self.moving = False 
            self.direction = None 
            #Definir límites del área permitida
            self.limete_superior = 500

        #Dibuja al jugador en pantalla
        def dibujar(self, screen): 
            screen.blit(self.image, self.rect.topleft) 

        #Actualiza la imagen del jugador para la animación.
        def update_image(self): 
            self.image_index = (self.image_index + 1) % len(self.images) 
            self.image = self.images[self.image_index] 

        #Mueve el personaje según la dirección específica
        def move(self): 
            if self.direction == 'up' and self.rect.top > 450: 
                self.rect.y -= move_speed 
            elif self.direction == 'down' and self.rect.bottom < screen_height: 
                self.rect.y += move_speed
            elif self.direction == 'left' and self.rect.left > Limite_Izquierda: 
                self.rect.x -= move_speed 
                self.images = self.images_iz
            elif self.direction == 'right' and self.rect.right < screen_width: 
                self.rect.x += move_speed
                self.images = self.images_der

    # Función para mover la imagen del obstáculo verifica que la misma no se salga de la ventana y alterna el sentido de iz a derecha
    
    class tronco:

        def __init__(self, image_path,pos, start_pos, move_distance, move_speed, moving_down = True):
            """Constructor para la clase tronco.

            Args:
                image_path (str): Ruta de la imagen del tronco
                start_pos (tuple): Posición inicial del tronco
                move_distance (int): Distancia que recorrera el tronco
                move_speed (float): Velocidad de movimiento del tronco
            """
            self.image = pygame.image.load(image_path)
            self.image = pygame.transform.scale(self.image, (50,25))
            self.rect = self.image.get_rect()
            self.rect.topleft = pos
            self.start_pos = start_pos
            self.end_pos = move_distance
            self.move_speed = move_speed
            self.moving_down = moving_down
        def dibujar(self, screen):
            """Método para dibujar el tronco en la pantalla

            Args:
                screen(pygame.surface): superficie donde se dibuja el tronco.
            """
            screen.blit(self.image, self.rect.topleft)
            
        def move(self):
            #Método para mover el tronco entre dos puntos (start_pos y end_pos). 
            #Invierte la dirección de movimiento cuando alcanza uno de los extremos.
            if self.moving_down:
                if self.rect.y < self.end_pos:
                    self.rect.y += self.move_speed
                else:
                    self.moving_down = False
            else:
                if self.rect.y > self.start_pos:
                   self.rect.y -= self.move_speed
                else:
                    self.moving_down = True
    
    #Crear insatancias de tronco con diferentes parámetros
    Obstaculo1 = tronco(Obstaculo, (200, screen_height // 1.7 +315), (screen_height// 2), screen_height, move_speed1_6 +  Velocidad, moving_down=False)
    obstaculo2 = tronco(Obstaculo, (300, screen_height // 1.7 +315), (screen_height// 2),screen_height, move_speed2_7 + Velocidad, moving_down=True)
    obstaculo3 = tronco(Obstaculo, (400, screen_height // 1.7 -25), (screen_height// 2),screen_height, move_speed3_8 + Velocidad,moving_down=True)
    obstaculo4 = tronco(Obstaculo, (500, screen_height // 1.7 +315), (screen_height// 2),screen_height, move_speed4_9 + Velocidad, moving_down=False)
    obstaculo5 = tronco(Obstaculo, (600, screen_height // 1.7 -25), (screen_height// 2),screen_height, move_speed5_10 + Velocidad,moving_down=True)
    obstaculo6 = tronco(Obstaculo, (900, screen_height // 1.7 +315), (screen_height// 2),screen_height, move_speed1_6 + Velocidad, moving_down=False)
    obstaculo7 = tronco(Obstaculo, (1000, screen_height // 1.7 -25),(screen_height// 2), screen_height, move_speed2_7 + Velocidad,moving_down=True)
    obstaculo8 = tronco(Obstaculo, (1100, screen_height // 1.7 +315),(screen_height// 2), screen_height, move_speed3_8 + Velocidad, moving_down=False)
    obstaculo9 = tronco(Obstaculo, (1200, screen_height // 1.7 -25), (screen_height// 2),screen_height, move_speed4_9 + Velocidad,moving_down=True)
    obstaculo10 = tronco(Obstaculo, (1300, screen_height // 1.7 +315), (screen_height// 2),screen_height, move_speed5_10 + Velocidad, moving_down=False)
    
    troncos = [Obstaculo1,obstaculo2,obstaculo3,obstaculo4,obstaculo5,obstaculo6,obstaculo7,obstaculo8,obstaculo9,obstaculo10]
    
    def move_troncos(troncos,estado):
        """Función para mover todos los troncos en el juego.

        Parametros:
            troncos (lsit): Lista de insatancias de la clase tronco.
        """
        while True:
            if not estado["pause"]:
                for tronco in troncos:
                    tronco.move()
            
            time.sleep(0.05)  # Controlar la velocidad de actualización

    # Crear y comenzar el hilo para mover la imagen del obstáculo
    move_thread = threading.Thread(target=move_troncos, args=(troncos, estado))
    move_thread.daemon = True  # Hilo en modo demonio para que se cierre con el programa
    move_thread.start() #Inicializa el hilo que hace mover el obstáculo

    # Bucle principal de Pygame 
    # Esta siempre verificando los eventos del teclado y las actualizaciones de la ventana
    jugador = Jugador()
    running = True
    def move_jugador():
        """Función para mover al jugador
        """
        while True:
            if jugador.moving:
                jugador.move()
                jugador.update_image()
            time.sleep(0.01)

    move_jugador_thread = threading.Thread(target=move_jugador)
    move_jugador_thread.daemon = True
    move_jugador_thread.start()


    while running:
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:   #Sale del ciclo y cierra la aplicación cuando el usuario cierra la venta en modo ventana tradicional
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:    #Sale del ciclo y cierra la aplicación cuando se preciona escape
                    running = False
                if event.key == pygame.K_p: #Pone pausa al movimiento de los obstáculos
                    estado["pause"] = not estado["pause"]
                    if estado["pause"]:
                        pygame.mixer.music.set_volume(0.1)
                    else:
                        pygame.mixer.music.set_volume(0.3)
                if event.key == pygame.K_UP: 
                    jugador.direction = 'up' 
                    jugador.moving = True 
                elif event.key == pygame.K_DOWN: 
                    jugador.direction = 'down' 
                    jugador.moving = True 
                elif event.key == pygame.K_LEFT: 
                    jugador.direction = 'left' 
                    jugador.moving = True 
                elif event.key == pygame.K_RIGHT: 
                    jugador.direction = 'right' 
                    jugador.moving = True 
            elif event.type == pygame.KEYUP: 
                if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]: 
                    jugador.moving = False
        
        screen.blit(background, (0, 0)) # Dibujar la imagen de fondo 
        jugador.dibujar(screen)
        
        screen.blit(Meta1, Posición_Meta1)
        screen.blit(text,text_rect)
        
        if llegada == 0:
            for tronco in troncos[5:]:
                tronco.dibujar(screen)
                Limite_Izquierda = 650
        if llegada == 5 or llegada == 10 or llegada == 15 or llegada == 20 or llegada == 25:
            for tronco in troncos[5:]:
                tronco.dibujar(screen)
                Limite_Izquierda = 650
                
        if Velocidad == 0:
            for tronco in troncos[5:]:
                tronco.dibujar(screen)
        else:
            for tronco in troncos:
                tronco.dibujar(screen)
            Limite_Izquierda = 0
            Meta = pygame.image.load("Meta.jpeg")
            Meta = pygame.transform.scale(Meta, (100,400))
            Posición_Meta = (50,500)
            rect_meta = Meta.get_rect(topleft = Posición_Meta)
            screen.blit(Meta, Posición_Meta)
            if jugador.rect.colliderect(rect_meta) and Velocidad:
                return False
            
        
        if any(jugador.rect.colliderect(tronco.rect) for tronco in troncos):
            Velocidad = 0
            llegada = 0
            return True
            # Agregar lo de morir
        
        
        
        if jugador.rect.colliderect(rect_meta1):
            llegada += 1
            if llegada == 25:
                llegada = 0
                return Preguntas.Final()
            return False
            #Establece la llegada
    
        pygame.display.flip() #Actualiza la pantalla

        # Controlar el framerate
        pygame.time.Clock().tick(60)

    # Salir de Pygame
    pygame.quit()
    sys.exit()