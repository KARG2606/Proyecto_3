import os

class ArbolBinario:
    def __init__(self, valor=None, nivel=1):
        self.valor = valor
        self.izquierdo = None
        self.derecho = None
        self.nivel = nivel

    def construir_arbol(self, lista_tuplas):
        self._construir_arbol_completo(lista_tuplas)

    def _construir_arbol_completo(self, lista_tuplas, nivel=1):
        if not lista_tuplas or nivel > 5:
            return None
        mid = len(lista_tuplas) // 2
        nodo = ArbolBinario(lista_tuplas[mid], nivel)
        nodo.izquierdo = self._construir_arbol_completo(lista_tuplas[:mid], nivel + 1)
        nodo.derecho = self._construir_arbol_completo(lista_tuplas[mid + 1:], nivel + 1)
        return nodo

    def recorrer_interactivamente(self):
        nodo = self
        while nodo is not None:
            print(f"Estás en el nodo con valor: {nodo.valor}")
            direccion = input("¿Quieres ir a la izquierda o a la derecha? (izquierda/derecha): ").strip().lower()
            if direccion == 'izquierda':
                nodo = nodo.izquierdo
            elif direccion == 'derecha':
                nodo = nodo.derecho
            else:
                print("Dirección no válida. Inténtalo de nuevo.")
        print("Has llegado a un nodo sin hijos.")

def comienzo(eleccion, cont):
    print(eleccion)
    ruta = os.path.dirname(os.path.abspath(__file__))
    preguntas_list = []
    respuestas = []
    errores = []
    opciones = []
    preguntas_info = []
    archivos = ["Bosque", "Espacio", "Desierto", "Océano", "Sabana"]
    if eleccion != archivos[0]:
        archivos.remove(eleccion)
        archivos.insert(0, eleccion)
    # Especifica el nombre del archivo correcto
    bioma = f'\\{archivos[cont]}.txt'

    with open(ruta + bioma, 'r', encoding='utf-8') as preguntas:
        for line in preguntas:
            if line.strip().startswith('Pregunta:'):
                nueva_linea = line.strip().replace('Pregunta:', '', 1).strip()
                preguntas_list.append(nueva_linea)
            elif line.strip().startswith('Respuesta:'):
                nueva_respuesta = line.strip().replace('Respuesta Correcta:', '', 1).strip()
                respuestas.append(nueva_respuesta)
            elif line.strip().startswith('Opciones:'):
                new_opcion = line.strip().replace('Opciones:', '', 1).strip()
                opciones.append(new_opcion)
            elif line.strip().startswith('Errores:'):
                new_error = line.strip().replace('Errores:', '', 1).strip()
                errores.append(int(new_error))

    # Asegurarse de que todas las listas tengan la misma longitud
    print(len(preguntas_list), len(respuestas), len(opciones), len(errores))
    if len(preguntas_list) == len(respuestas) == len(opciones) == len(errores):
        for i in range(len(preguntas_list)):
            preguntas_info.append((preguntas_list[i], opciones[i], respuestas[i], errores[i]))
        
        # Ordenar la lista de tuplas por el cuarto elemento (errores) de menor a mayor
        preguntas_ordenadas = sorted(preguntas_info, key=lambda x: x[3])
    else:
        print("Las listas no tienen la misma longitud. Verifica el archivo de entrada.")
        preguntas_ordenadas = []

    # Crear el árbol binario y construir el árbol completo
    arbol = ArbolBinario()
    arbol = arbol._construir_arbol_completo(preguntas_ordenadas)

    # Recorrer el árbol iterativamente
    arbol.recorrer_interactivamente()
    return arbol

# Llamada a la función comienzo
comienzo('Bosque', 0)
